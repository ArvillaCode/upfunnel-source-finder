// content-script.js — Módulo de resaltado quirúrgico

(function () {
  "use strict";

  if (window.__curatorAI_active) return;
  window.__curatorAI_active = true;

  const style = document.createElement("style");
  style.id = "curatorai-styles";
  style.textContent = `
    .curatorai-highlight {
      background-color: rgba(255, 235, 59, 0.55) !important;
      border-radius: 2px !important;
      padding: 0 2px !important;
      cursor: pointer !important;
      transition: background-color 0.2s ease !important;
      box-decoration-break: clone !important;
      -webkit-box-decoration-break: clone !important;
    }
    .curatorai-highlight:hover {
      background-color: rgba(255, 193, 7, 0.75) !important;
    }
    .curatorai-tooltip {
      position: fixed !important;
      background: #1a1a2e !important;
      color: #e0e0e0 !important;
      padding: 4px 10px !important;
      border-radius: 6px !important;
      font-size: 12px !important;
      font-family: system-ui, sans-serif !important;
      z-index: 2147483647 !important;
      pointer-events: none !important;
      opacity: 0 !important;
      transition: opacity 0.15s ease !important;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3) !important;
    }
    .curatorai-tooltip.visible { opacity: 1 !important; }
  `;
  document.head.appendChild(style);

  const tooltip = document.createElement("div");
  tooltip.className = "curatorai-tooltip";
  tooltip.textContent = "✓ Guardado";
  document.body.appendChild(tooltip);

  document.addEventListener("mouseup", handleMouseUp, { passive: true });

  // Estado de captura: por defecto activo. Se sincroniza con chrome.storage.local
  // (key "captureEnabled") para que el toggle del sidepanel y el atajo de teclado
  // lo controlen desde cualquier lado.
  let captureEnabled = true;
  chrome.storage.local.get(["captureEnabled"], (result) => {
    captureEnabled = result.captureEnabled !== false; // default true si nunca se configuró
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.captureEnabled) {
      captureEnabled = changes.captureEnabled.newValue !== false;
    }
  });

  function handleMouseUp(event) {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) return;
    const text = selection.toString().trim();
    if (text.length < 3) return;

    // Dos formas de saltarse el resaltado sin tocar el panel:
    // 1. Captura global apagada (toggle o atajo Alt+Shift+H)
    // 2. Mantener Alt presionado durante la selección — para copiar puntual
    //    sin afectar el estado global ni tener que ir y volver al panel.
    if (!captureEnabled) {
      showTooltip(event.clientX, event.clientY, "⏸ Captura pausada");
      return;
    }
    if (event.altKey) return;

    const range = selection.getRangeAt(0);
    if (!isRangeValid(range)) return;
    if (!chrome.runtime?.id) {
      warnInvalidatedOnce();
      return;
    }
    const id = Date.now();

    // El guardado en storage es independiente del resaltado visual:
    // si el DOM es complejo (selección multi-párrafo) y el pintado visual
    // falla parcialmente, el highlight igual debe quedar guardado.
    saveHighlight(text, id);

    try {
      wrapRangeWithHighlight(range, text, id);
      showTooltip(event.clientX, event.clientY);
    } catch (err) {
      if (err.message?.includes("Extension context invalidated")) {
        warnInvalidatedOnce();
      } else {
        console.warn("[CuratorAI] No se pudo pintar el resaltado visual (pero sí se guardó):", err.message);
      }
    }
    selection.removeAllRanges();
  }

  let invalidatedWarned = false;
  function warnInvalidatedOnce() {
    if (invalidatedWarned) return;
    invalidatedWarned = true;
    console.warn("[CuratorAI] La extensión fue actualizada — recarga esta página para seguir resaltando.");
  }

  function isRangeValid(range) {
    const container = range.commonAncestorContainer;
    const node = container.nodeType === 3 ? container.parentNode : container;
    const forbidden = ["INPUT", "TEXTAREA", "SELECT", "SCRIPT", "STYLE"];
    if (forbidden.includes(node.tagName)) return false;
    if (node.isContentEditable) return false;
    return true;
  }

  function wrapRangeWithHighlight(range, text, id) {
    // surroundContents() solo funciona si el range vive dentro de un único
    // nodo padre. Una selección que cruza varios <p> (como un párrafo completo
    // arrastrado con el mouse) lo rompe. highlightRange() resuelve esto
    // recorriendo cada nodo de texto tocado por el range y envolviéndolo
    // individualmente — así cada <p> seleccionado recibe su propio <span>,
    // todos compartiendo el mismo data-curator-id.
    try {
      const span = document.createElement("span");
      span.className = "curatorai-highlight";
      span.dataset.curatorText = text;
      span.dataset.curatorTs = Date.now();
      span.dataset.curatorId = id;
      range.surroundContents(span);
      return;
    } catch {
      // sigue abajo con el método multi-nodo
    }
    highlightRangeMultiNode(range, id);
  }

  function highlightRangeMultiNode(range, id) {
    const walker = document.createTreeWalker(
      range.commonAncestorContainer,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          return range.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        },
      }
    );

    const textNodes = [];
    let node;
    while ((node = walker.nextNode())) textNodes.push(node);

    textNodes.forEach((textNode) => {
      const nodeRange = document.createRange();
      nodeRange.selectNodeContents(textNode);
      if (textNode === range.startContainer) nodeRange.setStart(textNode, range.startOffset);
      if (textNode === range.endContainer) nodeRange.setEnd(textNode, range.endOffset);
      if (nodeRange.collapsed) return;

      const span = document.createElement("span");
      span.className = "curatorai-highlight";
      span.dataset.curatorTs = Date.now();
      span.dataset.curatorId = id;
      try {
        nodeRange.surroundContents(span);
      } catch (err) {
        console.warn("[CuratorAI] No se pudo pintar un fragmento del resaltado:", err.message);
      }
    });
  }

  function saveHighlight(text, id) {
    const highlight = {
      id,
      text,
      url: window.location.href,
      pageTitle: document.title,
      timestamp: new Date().toISOString(),
    };
    chrome.runtime.sendMessage({ action: "saveHighlight", highlight }, () => {
      void chrome.runtime.lastError;
    });
  }

  function showTooltip(x, y, message) {
    tooltip.textContent = message || "✓ Guardado";
    tooltip.style.left = `${Math.min(x + 10, window.innerWidth - 120)}px`;
    tooltip.style.top = `${Math.max(y - 35, 10)}px`;
    tooltip.classList.add("visible");
    setTimeout(() => tooltip.classList.remove("visible"), 1500);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "removeHighlights") {
      document.querySelectorAll(".curatorai-highlight").forEach((el) => {
        const parent = el.parentNode;
        while (el.firstChild) parent.insertBefore(el.firstChild, el);
        parent.removeChild(el);
      });
    }
    if (message.action === "removeHighlightById") {
      const el = document.querySelector(`[data-curator-id="${message.id}"]`);
      if (!el) return;
      const parent = el.parentNode;
      while (el.firstChild) parent.insertBefore(el.firstChild, el);
      parent.removeChild(el);
      parent.normalize();
    }
  });
})();
