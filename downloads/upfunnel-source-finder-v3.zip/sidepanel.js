// sidepanel.js — Lógica del Side Panel

(function () {
  "use strict";

  let currentScreenshot = null;
  let allSources = {};

  document.addEventListener("DOMContentLoaded", () => {
    initTheme();
    initTabs();
    initHighlightsPanel();
    initCapturePanel();
    initSettingsPanel();
    initExportPanel();
    initCaptureToggle();
    updatePageInfo();
    loadAllData();
  });

  function loadAllData() {
    chrome.storage.local.get(["highlights", "sources"], (result) => {
      allSources = result.sources || {};
      renderHighlights(result.highlights || []);
    });
  }

  // ── Theme ─────────────────────────────────────────────────────────

  function initTheme() {
    const saved = localStorage.getItem("theme");
    if (saved) {
      setTheme(saved);
    } else if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(["theme"], (r) => {
        setTheme(r.theme || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
      });
    } else {
      setTheme(window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    }

    document.getElementById("themeToggle").addEventListener("click", toggleTheme);

    document.addEventListener("keydown", (e) => {
      if (e.altKey && e.key.toLowerCase() === "t") {
        e.preventDefault();
        toggleTheme();
      }
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    if (chrome.storage && chrome.storage.local) chrome.storage.local.set({ theme });
    updateThemeIcon(theme);
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme");
    setTheme(current === "light" ? "dark" : "light");
  }

  function updateThemeIcon(theme) {
    const sun = document.querySelector(".icon-sun");
    const moon = document.querySelector(".icon-moon");
    if (sun && moon) {
      sun.style.display = theme === "dark" ? "none" : "block";
      moon.style.display = theme === "dark" ? "block" : "none";
    }
  }

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.highlights || changes.sources) loadAllData();
    if (changes.captureEnabled) {
      const checkbox = document.getElementById("captureToggle");
      if (checkbox) checkbox.checked = changes.captureEnabled.newValue !== false;
    }
  });

  // ── Capture Toggle ───────────────────────────────────────────────

  function initCaptureToggle() {
    const checkbox = document.getElementById("captureToggle");
    chrome.storage.local.get(["captureEnabled"], (result) => {
      checkbox.checked = result.captureEnabled !== false;
    });
    checkbox.addEventListener("change", () => {
      chrome.storage.local.set({ captureEnabled: checkbox.checked });
    });
  }

  // ── Tabs ─────────────────────────────────────────────────────────

  function initTabs() {
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        const target = tab.dataset.tab;
        document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
        document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
        tab.classList.add("active");
        document.getElementById(`panel-${target}`).classList.add("active");
        if (target === "settings") refreshApiStatus();
      });
    });
  }

  async function updatePageInfo() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      const info = document.getElementById("pageInfo");
      info.textContent = truncate(tab.title || tab.url, 28);
      info.title = tab.title || tab.url;
    }
  }

  // ── Panel de Resaltados ──────────────────────────────────────────

  function initHighlightsPanel() {
    document.getElementById("clearHighlightsBtn").addEventListener("click", async () => {
      if (!confirm("Eliminar todos los resaltados?")) return;
      chrome.storage.local.set({ highlights: [], sources: {} }, () => {
        allSources = {};
        renderHighlights([]);
        chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
          if (tab) chrome.tabs.sendMessage(tab.id, { action: "removeHighlights" });
        });
      });
    });

    document.getElementById("exportSourcesBtn").addEventListener("click", () => {
      const rows = [["highlight_id", "title", "url", "why_relevant"]];
      for (const [hlId, sources] of Object.entries(allSources)) {
        sources.forEach((s) => {
          const d = s.json || s;
          rows.push([hlId, (d.title || "").replace(/"/g, '""'), (d.url || "").replace(/"/g, '""'), (d.why_relevant || "").replace(/"/g, '""')]);
        });
      }
      if (rows.length <= 1) { alert("No hay fuentes para exportar."); return; }
      const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fuentes-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    });
  }

  function renderHighlights(highlights) {
    const list = document.getElementById("highlightsList");
    const badge = document.getElementById("hlCount");
    badge.textContent = highlights.length;
    if (!highlights.length) {
      list.innerHTML = `<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg><p>Selecciona texto en cualquier pagina<br />para guardar resaltados aqui</p></div>`;
      return;
    }

    list.innerHTML = highlights
      .slice()
      .reverse()
      .map((h) => {
        const sources = allSources[h.id] || [];
        const sourcesId = `sources-${h.id}`;
        const sourcesHtml =
          sources.length > 0
            ? `<div class="sources-container" data-hl-id="${h.id}">
                <button class="sources-toggle" data-target="${sourcesId}">
                  <span class="arrow">&#9654;</span> Fuentes (${sources.length})
                </button>
                <div class="sources-list" id="${sourcesId}">
                  ${sources
                    .map(
                      (s, i) => `
                    <div class="source-item">
                      <button class="source-delete" data-hl-id="${h.id}" data-idx="${i}" title="Eliminar fuente">✕</button>
                      <div class="source-title">${escapeHtml(s.title || "Sin titulo")}</div>
                      <a class="source-url" href="${escapeHtml(s.url || "")}" target="_blank">${escapeHtml(s.url || "")}</a>
                      ${s.why_relevant ? `<div class="source-why">${escapeHtml(s.why_relevant)}</div>` : ""}
                    </div>`
                    )
                    .join("")}
                </div>
              </div>`
            : `<div class="sources-container" data-hl-id="${h.id}"></div>`;

        return `<div class="highlight-item" data-id="${h.id}">
          <button class="delete-btn" data-id="${h.id}" title="Eliminar">✕</button>
          <div class="highlight-text">${escapeHtml(h.text)}</div>
          <div class="highlight-meta">
            <a class="highlight-url" href="${escapeHtml(h.url || "")}" target="_blank">${escapeHtml(h.pageTitle || h.url || "Sin fuente")}</a>
            <span>${formatDate(h.timestamp)}</span>
          </div>
          <div style="display:flex;gap:4px;margin-top:6px;flex-wrap:wrap;">
            <button class="find-sources-btn" data-id="${h.id}" data-text="${escapeHtml(h.text)}">🔍 Buscar fuentes</button>
            <button class="gen-btn gen-idea" data-id="${h.id}" data-text="${escapeHtml(h.text)}">Generar Idea</button>
            <button class="gen-btn gen-script" data-id="${h.id}" data-text="${escapeHtml(h.text)}">Generar Script</button>
            <button class="gen-btn gen-summary" data-id="${h.id}" data-text="${escapeHtml(h.text)}">Resumir</button>
          </div>
          <div class="gen-content" id="gen-${h.id}-idea"></div>
          <div class="gen-content" id="gen-${h.id}-script"></div>
          <div class="gen-content" id="gen-${h.id}-summary"></div>
          ${sourcesHtml}
        </div>`;
      })
      .join("");

    list.querySelectorAll(".delete-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        deleteHighlight(parseInt(btn.dataset.id));
      });
    });

    list.querySelectorAll(".find-sources-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        findSourcesForHighlight(parseInt(btn.dataset.id), btn.dataset.text, btn);
      });
    });

    list.querySelectorAll(".sources-toggle").forEach((btn) => {
      btn.addEventListener("click", () => {
        const target = document.getElementById(btn.dataset.target);
        if (target) {
          btn.classList.toggle("open");
          target.classList.toggle("open");
        }
      });
    });

    list.querySelectorAll(".source-delete").forEach((btn) => {
      btn.addEventListener("click", () => {
        deleteSourceFromHighlight(btn.dataset.hlId, parseInt(btn.dataset.idx));
      });
    });

    list.querySelectorAll(".gen-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = parseInt(btn.dataset.id);
        const text = btn.dataset.text;
        const type = btn.classList.contains("gen-idea")
          ? "idea"
          : btn.classList.contains("gen-script")
          ? "script"
          : "summary";
        generateContent(id, text, type, btn);
      });
    });
  }

  function deleteHighlight(id) {
    chrome.runtime.sendMessage({ action: "deleteHighlight", id }, () => void chrome.runtime.lastError);
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, { action: "removeHighlightById", id }, () => void chrome.runtime.lastError);
      });
    });
  }

  async function findSourcesForHighlight(highlightId, text, btn) {
    btn.disabled = true;
    btn.innerHTML =
      '<span class="spinner" style="width:10px;height:10px;border:2px solid var(--border);border-top-color:var(--text-muted);border-radius:50%;display:inline-block;animation:spin 0.6s linear infinite;"></span> Buscando...';

    const container = document.querySelector(`.sources-container[data-hl-id="${highlightId}"]`);
    if (container) {
      container.innerHTML = '<div class="sources-loading"><div class="spinner"></div> Buscando fuentes...</div>';
    }

    try {
      const response = await sendMessage({ action: "findSources", highlightId, text });

      if (response?.success && response.sources?.length > 0) {
        allSources[highlightId] = response.sources;
        chrome.storage.local.get(["highlights"], (result) => renderHighlights(result.highlights || []));
      } else if (response?.success && response.sources?.length === 0) {
        if (container) container.innerHTML = '<div class="sources-loading" style="color:var(--text-muted);">No se encontraron fuentes.</div>';
      } else {
        if (container) container.innerHTML = `<div class="sources-loading" style="color:var(--red);">Error: ${escapeHtml(response?.error || "Sin respuesta")}</div>`;
      }

      // Si Sheets webhook está configurado, guardar automáticamente
      if (response?.success && response.sources?.length > 0) {
        const { sheetsWebhookUrl, highlights } = await chrome.storage.local.get(["sheetsWebhookUrl", "highlights"]);
        if (sheetsWebhookUrl) {
          const hl = (highlights || []).find(h => h.id === highlightId);
          const pageUrl = hl?.url || "";
          const pageTitle = hl?.pageTitle || "";
          for (const source of response.sources) {
            // Traducir snippet al español si es necesario
            let whyRelevant = source.why_relevant || "";
            if (whyRelevant && /[a-z]{4,}/i.test(whyRelevant) && !/[áéíóúñ¿¡]/i.test(whyRelevant)) {
              try {
                const translated = await sendMessage({ action: "translateText", text: whyRelevant });
                if (translated?.success) whyRelevant = translated.translated;
              } catch (e) {}
            }
            chrome.runtime.sendMessage({
              action: "sheetsAppendRow",
              values: [
                String(highlightId),
                text,
                pageUrl,
                pageTitle,
                source.title,
                source.url,
                whyRelevant,
                new Date().toISOString(),
              ],
            }, (res) => {
              if (chrome.runtime.lastError || !res?.success) {
                console.warn("[Sheets] Error al guardar:", chrome.runtime.lastError?.message || res?.error);
              }
            });
          }
        }
      }
    } catch (err) {
      if (container) container.innerHTML = `<div class="sources-loading" style="color:var(--red);">Error: ${escapeHtml(err.message)}</div>`;
    } finally {
      btn.disabled = false;
      btn.innerHTML = "🔍 Buscar fuentes";
    }
  }

  async function deleteSourceFromHighlight(highlightId, sourceIndex) {
    await sendMessage({ action: "deleteSource", highlightId, sourceIndex });
  }

  async function generateContent(highlightId, text, type, btn) {
    const container = document.getElementById(`gen-${highlightId}-${type}`);
    if (!container) return;

    btn.disabled = true;
    const originalText = btn.textContent;
    btn.textContent = "Generando...";
    container.innerHTML = '<div class="gen-header"><span class="gen-label">Generando...</span></div><div class="gen-body">Procesando...</div>';
    container.classList.add("visible");

    try {
      const response = await sendMessage({ action: "generateAI", highlightId, text, type });
      if (response && response.success && response.generated_text) {
        const labelMap = { idea: "💡 Idea generada", script: "📝 Script generado", summary: "📄 Resumen" };
        const bodyId = `gen-body-${highlightId}-${type}`;
        container.innerHTML = `
          <div class="gen-header">
            <span class="gen-label">${labelMap[type] || "Contenido"}</span>
            <div class="gen-actions">
              <button class="gen-copy" data-target="${bodyId}" title="Copiar">📋</button>
              <button class="gen-toggle" data-target="${bodyId}" title="Contraer">▼</button>
            </div>
          </div>
          <div class="gen-body" id="${bodyId}">${formatGenContent(response.generated_text)}</div>
        `;
        // Copiar
        container.querySelector('.gen-copy')?.addEventListener('click', (e) => {
          e.stopPropagation();
          const body = document.getElementById(e.target.dataset.target);
          if (!body) return;
          const text = body.textContent || body.innerText;
          navigator.clipboard.writeText(text).then(() => {
            e.target.textContent = '✅';
            setTimeout(() => { e.target.textContent = '📋'; }, 1500);
          });
        });
        // Toggle colapsar
        container.querySelector('.gen-toggle')?.addEventListener('click', (e) => {
          e.stopPropagation();
          const body = document.getElementById(e.target.dataset.target);
          if (!body) return;
          const isCollapsed = body.style.display === 'none';
          body.style.display = isCollapsed ? 'block' : 'none';
          e.target.classList.toggle('collapsed', !isCollapsed);
          e.target.title = isCollapsed ? 'Contraer' : 'Expandir';
        });
      } else {
        container.innerHTML = `<div class="gen-label" style="color:var(--red)">Error</div>${escapeHtml(response?.error || "Sin respuesta. Configura tu API key en Settings.")}`;
      }
    } catch (err) {
      container.innerHTML = `<div class="gen-label" style="color:var(--red)">Error</div>${escapeHtml(err.message)}`;
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  }

  // ── Panel de Captura ─────────────────────────────────────────────

  function initCapturePanel() {
    const captureBtn = document.getElementById("captureBtn");
    const downloadBtn = document.getElementById("downloadBtn");
    const saveCapBtn = document.getElementById("saveCapBtn");
    const discardCapBtn = document.getElementById("discardCapBtn");
    const decisionRow = document.getElementById("decisionRow");
    const canvas = document.getElementById("screenshotCanvas");
    const captureArea = document.getElementById("captureArea");

    let pendingCapture = null;

    captureBtn.addEventListener("click", async () => {
      captureBtn.disabled = true;
      captureBtn.textContent = "Capturando...";
      try {
        const response = await sendMessage({ action: "captureTab" });
        if (!response || !response.success) throw new Error(response?.error || "Error desconocido");
        currentScreenshot = response.dataUrl;
        pendingCapture = { dataUrl: response.dataUrl, meta: response.meta };
        renderScreenshot(canvas, captureArea, response.dataUrl);
        decisionRow.style.display = "flex";
      } catch (err) {
        captureArea.innerHTML = `<div class="capture-placeholder"><span>⚠</span>Error: ${escapeHtml(err.message)}</div>`;
        pendingCapture = null;
        decisionRow.style.display = "none";
      } finally {
        captureBtn.disabled = false;
        captureBtn.textContent = "Capturar pantalla";
      }
    });

    saveCapBtn.addEventListener("click", async () => {
      if (!pendingCapture) return;
      saveCapBtn.disabled = true;
      saveCapBtn.textContent = "Guardando...";
      try {
        const response = await sendMessage({ action: "saveCapture", ...pendingCapture });
        if (!response || !response.success) throw new Error("No se pudo guardar");
        loadCapturesHistory();
        resetCaptureState();
      } catch (err) {
        console.warn("[UpFunnel] Error al guardar captura:", err.message);
      } finally {
        saveCapBtn.disabled = false;
        saveCapBtn.textContent = "Guardar en historial";
      }
    });

    discardCapBtn.addEventListener("click", resetCaptureState);

    downloadBtn.addEventListener("click", () => {
      if (!currentScreenshot) return;
      const a = document.createElement("a");
      a.href = currentScreenshot;
      a.download = `capture_${Date.now()}.png`;
      a.click();
    });

    function resetCaptureState() {
      pendingCapture = null;
      currentScreenshot = null;
      decisionRow.style.display = "none";
      canvas.style.display = "none";
      captureArea.innerHTML = `<div class="capture-placeholder"><span>+</span>Haz clic en "Capturar pantalla"<br />para tomar una foto de la pestana activa</div>`;
    }

    loadCapturesHistory();
  }

  function loadCapturesHistory() {
    chrome.storage.local.get(["captures"], (result) => renderCaptures(result.captures || []));
  }

  function renderCaptures(captures) {
    const list = document.getElementById("capturesList");
    const badge = document.getElementById("capCount");
    badge.textContent = captures.length;
    if (!captures.length) {
      list.innerHTML = `<div class="empty-state" style="padding:12px 0;"><p style="font-size:11px;color:var(--text-muted);">Aun no hay capturas guardadas</p></div>`;
      return;
    }
    list.innerHTML = captures
      .slice()
      .reverse()
      .map(
        (c) => `<div class="capture-item" data-id="${c.id}">
          <img class="capture-thumb" src="${c.dataUrl}" data-id="${c.id}" title="Ver en grande" />
          <div class="capture-info">
            <div class="capture-title">${escapeHtml(c.title || "Sin título")}</div>
            <div class="capture-meta">${formatDate(c.timestamp)}</div>
          </div>
          <div class="capture-actions">
            <button class="cap-view" data-id="${c.id}" title="Ver en grande"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
            <button class="cap-download" data-id="${c.id}" title="Descargar"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
            <button class="cap-delete" data-id="${c.id}" title="Eliminar">✕</button>
          </div>
        </div>`
      )
      .join("");

    const findCapture = (id) => captures.find((c) => c.id === id);

    list.querySelectorAll(".capture-thumb, .cap-view").forEach((el) => {
      el.addEventListener("click", () => {
        const cap = findCapture(parseInt(el.dataset.id));
        if (!cap) return;
        currentScreenshot = cap.dataUrl;
        renderScreenshot(document.getElementById("screenshotCanvas"), document.getElementById("captureArea"), cap.dataUrl);
        document.getElementById("decisionRow").style.display = "none";
      });
    });

    list.querySelectorAll(".cap-download").forEach((btn) => {
      btn.addEventListener("click", () => {
        const cap = findCapture(parseInt(btn.dataset.id));
        if (!cap) return;
        const a = document.createElement("a");
        a.href = cap.dataUrl;
        a.download = `capture_${cap.id}.png`;
        a.click();
      });
    });

    list.querySelectorAll(".cap-delete").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.dataset.id);
        await sendMessage({ action: "deleteCaptureById", id });
        loadCapturesHistory();
      });
    });
  }

  function renderScreenshot(canvas, area, dataUrl) {
    const img = new Image();
    img.onload = () => {
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);
      area.innerHTML = "";
      canvas.style.display = "block";
      area.appendChild(canvas);
    };
    img.src = dataUrl;
  }

  // ── Panel de Configuración ───────────────────────────────────────

  function initSettingsPanel() {
    loadApiKeysIntoForm();
    setupSaveApiKeys();
    setupSheetsButtons();
    setupGeminiDetection();
  }

  async function loadApiKeysIntoForm() {
    const { apiKeys, preferredSearch, preferredAI } = await chrome.storage.local.get([
      "apiKeys",
      "preferredSearch",
      "preferredAI",
    ]);

    if (apiKeys.serper) document.getElementById("serperKey").value = apiKeys.serper;
    if (apiKeys.googleCse?.apiKey) document.getElementById("googleCseKey").value = apiKeys.googleCse.apiKey;
    if (apiKeys.googleCse?.cx) document.getElementById("googleCseCx").value = apiKeys.googleCse.cx;
    if (apiKeys.openai) document.getElementById("openaiKey").value = apiKeys.openai;
    if (apiKeys.claude) document.getElementById("claudeKey").value = apiKeys.claude;
    if (apiKeys.openrouter) document.getElementById("openrouterKey").value = apiKeys.openrouter;
    if (apiKeys.openrouterModel) document.getElementById("openrouterModel").value = apiKeys.openrouterModel;
    if (preferredSearch) document.getElementById("searchPriority").value = preferredSearch;
    if (preferredAI) document.getElementById("aiPriority").value = preferredAI;
  }

  function setupSaveApiKeys() {
    document.getElementById("saveApiKeysBtn").addEventListener("click", async () => {
      const apiKeys = {
        serper: document.getElementById("serperKey").value.trim(),
        googleCse: {
          apiKey: document.getElementById("googleCseKey").value.trim(),
          cx: document.getElementById("googleCseCx").value.trim(),
        },
        openai: document.getElementById("openaiKey").value.trim(),
        claude: document.getElementById("claudeKey").value.trim(),
        openrouter: document.getElementById("openrouterKey").value.trim(),
        openrouterModel: document.getElementById("openrouterModel").value.trim() || "openai/gpt-4o-mini",
      };

      const preferredSearch = document.getElementById("searchPriority").value;
      const preferredAI = document.getElementById("aiPriority").value;

      await sendMessage({ action: "saveApiKeys", apiKeys });
      await sendMessage({ action: "savePreferences", preferredSearch, preferredAI });

      const status = document.getElementById("apiSaveStatus");
      status.textContent = "✅ Configuracion guardada";
      status.style.display = "inline-flex";
      setTimeout(() => { status.style.display = "none"; }, 3000);

      refreshApiStatus();
    });
  }

  function setupSheetsButtons() {
    // Cargar estado actual
    chrome.storage.local.get(["sheetsWebhookUrl", "sheetsConnected"], (r) => {
      if (r.sheetsWebhookUrl) document.getElementById("sheetsWebhookInput").value = r.sheetsWebhookUrl;
      if (r.sheetsConnected) showSheetsConnected();
    });

    // Botón "Crear sheet" → abre sheet.best
    document.getElementById("sheetsCreateBtn").addEventListener("click", () => {
      chrome.tabs.create({ url: "https://sheet.best" });
    });

    document.getElementById("sheetsSaveBtn").addEventListener("click", async () => {
      const url = document.getElementById("sheetsWebhookInput").value.trim();
      if (!url) { alert("Ingresá una URL primero"); return; }

      const btn = document.getElementById("sheetsSaveBtn");
      btn.disabled = true;
      btn.textContent = "Probando...";

      try {
        const res = await sendMessage({ action: "sheetsTestWebhook", url });
        if (res.success) {
          await sendMessage({ action: "sheetsSaveUrl", url });
          showSheetsConnected();
          showSheetsStatus("✅ Conectado correctamente", "ok");
        } else {
          showSheetsStatus("❌ " + (res.error || "No respondió"), "error");
        }
      } catch (err) {
        showSheetsStatus("❌ " + err.message, "error");
      } finally {
        btn.disabled = false;
        btn.textContent = "Conectar";
      }
    });

    document.getElementById("sheetsTestBtn")?.addEventListener("click", async () => {
      const { sheetsWebhookUrl } = await chrome.storage.local.get(["sheetsWebhookUrl"]);
      if (!sheetsWebhookUrl) { alert("No hay webhook configurado"); return; }

      const btn = document.getElementById("sheetsTestBtn");
      btn.disabled = true;
      btn.textContent = "Probando...";

      try {
        const res = await sendMessage({
          action: "sheetsAppendRow",
          values: ["TEST", "Prueba de conexión", "", "", "UpFunnel Source Finder", "https://upfunnel.com", "Test", new Date().toISOString()],
        });
        if (res.success) {
          showSheetsStatus("✅ Escritura exitosa!", "ok");
        } else {
          showSheetsStatus("❌ " + (res.error || "Falló"), "error");
        }
      } catch (err) {
        showSheetsStatus("❌ " + err.message, "error");
      } finally {
        btn.disabled = false;
        btn.textContent = "Probar";
      }
    });

    document.getElementById("sheetsDisconnectBtn").addEventListener("click", async () => {
      await sendMessage({ action: "sheetsDisconnect" });
      document.getElementById("sheetsWebhookInput").value = "";
      document.getElementById("sheetsWebhookInput").disabled = false;
      document.getElementById("sheetsSaveBtn").style.display = "inline-flex";
      document.getElementById("sheetsCreateBtn").style.display = "inline-flex";
      document.getElementById("sheetsTestBtn").style.display = "none";
      document.getElementById("sheetsDisconnectBtn").style.display = "none";
      showSheetsStatus("", "");
      refreshApiStatus();
    });
  }

  function showSheetsConnected() {
    document.getElementById("sheetsSaveBtn").style.display = "none";
    document.getElementById("sheetsCreateBtn").style.display = "none";
    document.getElementById("sheetsWebhookInput").disabled = true;
    document.getElementById("sheetsTestBtn").style.display = "inline-flex";
    document.getElementById("sheetsDisconnectBtn").style.display = "inline-flex";
    refreshApiStatus();
  }

  function showSheetsStatus(text, type) {
    const el = document.getElementById("sheetsStatus");
    if (!text) { el.style.display = "none"; return; }
    el.textContent = text;
    el.className = "status-badge " + type;
    el.style.display = "inline-flex";
    setTimeout(() => { el.style.display = "none"; }, 4000);
  }

  function setupGeminiDetection() {
    sendMessage({ action: "checkGeminiNano" }).then((response) => {
      const hint = document.getElementById("geminiHint");
      if (response?.available) {
        hint.textContent = "✅ Gemini Nano disponible en este navegador. No necesita API key.";
      } else {
        hint.textContent = "⚠️ Gemini Nano requiere Chrome 128+. Selecciona OpenAI o Claude si no está disponible.";
      }
    });
  }

  // ── API Status ────────────────────────────────────────────────────

  async function refreshApiStatus() {
    const { apiKeys, sheetsWebhookUrl } = await chrome.storage.local.get(["apiKeys", "sheetsWebhookUrl"]);

    setStatusDot("status-serper", apiKeys.serper ? "ok" : "pending", apiKeys.serper ? "✅ Serper.dev configurado" : "⬜ Serper.dev — no configurado");
    setStatusDot(
      "status-googlecse",
      apiKeys.googleCse?.apiKey && apiKeys.googleCse?.cx ? "ok" : "pending",
      apiKeys.googleCse?.apiKey && apiKeys.googleCse?.cx ? "✅ Google CSE configurado" : "⬜ Google CSE — no configurado"
    );
    setStatusDot("status-openai", apiKeys.openai ? "ok" : "pending", apiKeys.openai ? "✅ OpenAI configurado" : "⬜ OpenAI — no configurado");
    setStatusDot("status-claude", apiKeys.claude ? "ok" : "pending", apiKeys.claude ? "✅ Claude configurado" : "⬜ Claude — no configurado");
    setStatusDot("status-openrouter", apiKeys.openrouter ? "ok" : "pending", apiKeys.openrouter ? "✅ OpenRouter configurado" : "⬜ OpenRouter — no configurado");
    setStatusDot("status-sheets", sheetsWebhookUrl ? "ok" : "pending", sheetsWebhookUrl ? "✅ Sheets conectado" : "⬜ Sheets — no configurado");
  }

  function setStatusDot(elementId, status, title) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const dot = el.querySelector(".status-dot-2");
    if (dot) {
      dot.className = "status-dot-2 " + status;
    }
    el.title = title;
  }

  // ── Panel de Export ──────────────────────────────────────────────

  function initExportPanel() {
    const exportBtn = document.getElementById("exportBtn");
    const copyJsonBtn = document.getElementById("copyJsonBtn");
    const jsonOutput = document.getElementById("jsonOutput");
    const exportStatus = document.getElementById("exportStatus");

    exportBtn.addEventListener("click", async () => {
      exportBtn.disabled = true;
      exportBtn.textContent = "Exportando...";
      exportStatus.className = "status-badge pending";
      exportStatus.textContent = "Consolidando datos...";
      try {
        const response = await sendMessage({ action: "exportToAI" });
        if (!response || !response.success) throw new Error(response?.error || "Fallo");
        jsonOutput.textContent = JSON.stringify(response.payload, null, 2);
        copyJsonBtn.disabled = false;
        exportStatus.className = "status-badge ok";
        exportStatus.textContent = `Exportado — ${(response.payload.highlights || []).length} resaltados`;
      } catch (err) {
        jsonOutput.textContent = `// Error: ${err.message}`;
        exportStatus.className = "status-badge error";
        exportStatus.textContent = "Error al exportar";
      } finally {
        exportBtn.disabled = false;
        exportBtn.textContent = "Exportar a IA";
      }
    });

    copyJsonBtn.addEventListener("click", () => {
      const text = jsonOutput.textContent;
      if (!text || text.startsWith("//")) return;
      navigator.clipboard.writeText(text).then(() => {
        copyJsonBtn.textContent = "Copiado!";
        setTimeout(() => (copyJsonBtn.textContent = "Copiar JSON"), 1500);
      });
    });
  }

  // ── Helpers ──────────────────────────────────────────────────────

  function sendMessage(payload) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Timeout del service worker")), 60000);
      chrome.runtime.sendMessage(payload, (response) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
  }

  function escapeHtml(str) {
    return String(str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ── Formatear contenido generado ──
  function formatGenContent(text) {
    if (!text) return '';
    let html = text;

    // 1. Normalizar saltos de línea (\r\n → \n, \r → \n)
    html = html.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // 2. Escapar HTML por seguridad
    html = html.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

    // 3. **texto** → negrita (antes de cualquier otro reemplazo de línea)
    html = html.replace(/\*\*(.+?)\*\*/gs, '<strong>$1</strong>');

    // 4. *texto* → itálica
    html = html.replace(/\*(.+?)\*/gs, '<em>$1</em>');

    // 5. [TÍTULO] → header estilizado (mayúsculas, números, espacios, tildes)
    html = html.replace(/\[([A-ZÁÉÍÓÚÑ\sÀ-ÿ0-9]+)\]/g, '<span class="gen-heading">[$1]</span>');

    // 6. --- o — separador → línea horizontal (en su propia línea)
    html = html.replace(/\n[-—]{3,}\n/g, '\n<hr>\n');
    html = html.replace(/^[-—]{3,}\n/gm, '<hr>\n');

    // 7. Convertir dobles saltos de línea en párrafos
    html = html.replace(/\n{2,}/g, '</p><p>');

    // 8. Saltos de línea simples
    html = html.replace(/\n/g, '<br>');

    // 9. Si no hay párrafos, envolver todo en uno
    if (!html.startsWith('<p>') && !html.startsWith('<strong>')) {
      html = '<p>' + html + '</p>';
    }

    return html;
  }

  function truncate(str, n) {
    return str && str.length > n ? str.slice(0, n) + "…" : str;
  }

  function formatDate(ts) {
    if (!ts) return "";
    return new Date(ts).toLocaleDateString("es-CO", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  }
})();
