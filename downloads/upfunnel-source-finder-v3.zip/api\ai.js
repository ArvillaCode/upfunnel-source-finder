// api/ai.js — Módulo de IA con múltiples providers

import { API_ENDPOINTS, AI_DEFAULTS, PROMPTS } from "./config.js";

// ── Providers ────────────────────────────────────────────────────────

async function openaiGenerate(prompt, apiKeys, signal) {
  const res = await fetch(API_ENDPOINTS.openai, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKeys.openai}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: AI_DEFAULTS.openaiModel,
      messages: [{ role: "user", content: prompt }],
      max_tokens: AI_DEFAULTS.maxTokens,
    }),
    signal,
  });

  if (!res.ok) throw new Error(`OpenAI HTTP ${res.status}`);
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

async function claudeGenerate(prompt, apiKeys, signal) {
  const res = await fetch(API_ENDPOINTS.claude, {
    method: "POST",
    headers: {
      "x-api-key": apiKeys.claude,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: AI_DEFAULTS.claudeModel,
      max_tokens: AI_DEFAULTS.maxTokens,
      messages: [{ role: "user", content: prompt }],
    }),
    signal,
  });

  if (!res.ok) throw new Error(`Claude HTTP ${res.status}`);
  const data = await res.json();
  return data.content?.[0]?.text || "";
}

async function openrouterGenerate(prompt, apiKeys, signal) {
  const res = await fetch(API_ENDPOINTS.openrouter, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKeys.openrouter}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://upfunnel.com",
      "X-Title": "UpFunnel Source Finder",
    },
    body: JSON.stringify({
      model: apiKeys.openrouterModel || AI_DEFAULTS.openrouterModel,
      messages: [{ role: "user", content: prompt }],
      max_tokens: AI_DEFAULTS.maxTokens,
    }),
    signal,
  });

  if (!res.ok) {
    const errBody = await res.text().catch(() => "");
    throw new Error(`OpenRouter HTTP ${res.status}: ${errBody.slice(0, 200)}`);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

async function geminiNanoGenerate(prompt, _apiKeys, _signal) {
  // Chrome Prompt API (Gemini Nano) - disponible desde Chrome 128+
  if (!self.ai?.languageModel) {
    throw new Error("Gemini Nano no disponible en este navegador");
  }

  const session = await self.ai.languageModel.create({
    systemPrompt: "Eres un asistente experto en investigación y análisis.",
  });

  try {
    const result = await session.prompt(prompt);
    return result;
  } finally {
    session.destroy();
  }
}

// ── Providers map ───────────────────────────────────────────────────

const providers = {
  openai: openaiGenerate,
  claude: claudeGenerate,
  openrouter: openrouterGenerate,
  "gemini-nano": geminiNanoGenerate,
};

// ── Prompt builder ──────────────────────────────────────────────────

function buildPrompt(type, text) {
  const template = PROMPTS[type];
  if (!template) throw new Error(`Tipo de prompt desconocido: ${type}`);

  const escapedText = text
    .replace(/"/g, "'")
    .replace(/\\/g, "/")
    .replace(/[\r\n]+/g, " ")
    .trim();

  return template.replace("{TEXT}", escapedText);
}

// ── Módulo público ──────────────────────────────────────────────────

/**
 * Genera contenido usando IA con el provider especificado.
 * @param {string} type - "idea" | "script" | "summary" | "analyzeSources"
 * @param {string} text - Texto base para la generación
 * @param {object} apiKeys - { openai, claude, openrouter, openrouterModel }
 * @param {string} preferredProvider - "openai" | "claude" | "openrouter" | "gemini-nano"
 * @param {object} [extra] - { sources } para analyzeSources
 * @returns {Promise<{success: boolean, generated_text?: string, provider?: string, error?: string}>}
 */
export async function generateWithAI(type, text, apiKeys, preferredProvider, extra) {
  const provider = preferredProvider || "openai";

  if (!providers[provider]) {
    return { success: false, error: `Provider de IA desconocido: ${provider}` };
  }

  // Validar que la key exista si no es Gemini Nano
  if (provider !== "gemini-nano" && !apiKeys[provider]) {
    return { success: false, error: `API key de ${provider} no configurada` };
  }

  // Validar disponibilidad de Gemini Nano
  if (provider === "gemini-nano" && !self.ai?.languageModel) {
    // Fallback automático a OpenAI o Claude si están configurados
    const fallback = apiKeys.openrouter ? "openrouter" : apiKeys.openai ? "openai" : apiKeys.claude ? "claude" : null;
    if (fallback) {
      return generateWithAI(type, text, apiKeys, fallback, extra);
    }
    return { success: false, error: "Gemini Nano no disponible. Configura OpenAI o Claude." };
  }

  let prompt;
  if (type === "analyzeSources" && extra?.sources) {
    const sourcesText = extra.sources
      .map((s, i) => `${i + 1}. "${s.title}" — ${s.url} — ${s.why_relevant}`)
      .join("\n");
    prompt = PROMPTS.analyzeSources.replace("{TEXT}", text).replace("{SOURCES}", sourcesText);
  } else {
    prompt = buildPrompt(type, text);
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), AI_DEFAULTS.timeout);

  try {
    const generatedText = await providers[provider](prompt, apiKeys, controller.signal);
    clearTimeout(timeout);
    return { success: true, generated_text: generatedText, provider };
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === "AbortError") {
      return { success: false, error: "La generación tardó demasiado (>30s)" };
    }
    return { success: false, error: err.message };
  }
}

/**
 * Detecta si Gemini Nano está disponible en el navegador.
 */
export async function isGeminiNanoAvailable() {
  try {
    const capabilities = await self.ai?.languageModel?.capabilities?.();
    return capabilities?.available !== "no";
  } catch {
    return false;
  }
}
