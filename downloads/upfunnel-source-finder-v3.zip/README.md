# UpFunnel Source Finder — Chrome Extension

> Extensión de Chrome para búsqueda de fuentes automáticas con IA. Sin backend propio, sin servidores, sin costos ocultos.

![Version](https://img.shields.io/badge/version-3.0.0-C8F04A)
![MV3](https://img.shields.io/badge/Manifest-V3-blue)
![No-Backend](https://img.shields.io/badge/No-Backend-green)

## ¿Qué hace?

Seleccionás texto en cualquier página → la extensión busca fuentes relacionadas (artículos, papers, datos, estadísticas). Cada usuario configura **sus propias API keys**. **Cero costo para el creador de la comunidad.**

## Estructura

```
upfunnel-source-finder/
├── manifest.json
├── service-worker.js          ← Orquestador (llama a APIs directamente)
├── content-script.js          ← Resaltado de texto
├── sidepanel.html             ← Interfaz del panel lateral
├── sidepanel.js               ← Lógica del panel
├── api/
│   ├── config.js              ← Endpoints, prompts, scoring
│   ├── search.js              ← Búsqueda con auto-failover
│   ├── ai.js                  ← IA (OpenAI, Claude, OpenRouter, Gemini Nano)
│   └── sheets.js              ← Google Sheets (OAuth)
└── icons/
```

## APIs que soporta

### Búsqueda de fuentes
| Servicio | Key | Costo | Prioridad |
|----------|-----|-------|-----------|
| Serper.dev | Sí | $50 gratis al registrarse | Principal |
| Google CSE | Sí | 100 consultas/día gratis | Fallback |
| DuckDuckGo | No | Gratis | Fallback final |

### Inteligencia Artificial
| Servicio | Key | Costo | Ideal para |
|----------|-----|-------|------------|
| OpenRouter | Sí | Modelos gratis disponibles + pago por uso | **Recomendado** — una key para todo |
| OpenAI | Sí | $5 gratis al registrarse, ~$0.15/1000 consultas | Usuarios que ya tienen key |
| Claude | Sí | Pago por uso | Usuarios de Anthropic |
| Gemini Nano | No | Gratis (Chrome 128+) | Sin configuración |

### Almacenamiento
| Servicio | Costo | Para qué |
|----------|-------|----------|
| Google Sheets | Gratis | Guardar fuentes automáticamente (opcional) |

## Instalación

1. Abrí `chrome://extensions/`
2. Activá "Modo desarrollador" (esquina superior derecha)
3. Clic en "Cargar descomprimida" → seleccioná la carpeta
4. Abrí el panel lateral (clic en el ícono de la extensión)
5. Andá a la pestaña **Config** y configurá tus API keys
6. Seleccioná texto en cualquier web → clic en "🔍 Buscar fuentes"

Sin servidores, sin n8n, sin webhooks. Todo desde el navegador.
