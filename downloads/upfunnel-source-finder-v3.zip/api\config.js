// api/config.js — Constantes, endpoints y configuración compartida

export const API_ENDPOINTS = {
  serper: "https://google.serper.dev/search",
  googleCse: "https://www.googleapis.com/customsearch/v1",
  duckduckgo: "https://api.duckduckgo.com/",
  openai: "https://api.openai.com/v1/chat/completions",
  claude: "https://api.anthropic.com/v1/messages",
  openrouter: "https://openrouter.ai/api/v1/chat/completions",
  sheets: "https://sheets.googleapis.com/v4/spreadsheets",
};

export const SEARCH_DEFAULTS = {
  numResults: 15,
  maxResults: 10,
  timeout: 15000,
};

export const AI_DEFAULTS = {
  openaiModel: "gpt-4o-mini",
  claudeModel: "claude-3-haiku-20240307",
  openrouterModel: "openai/gpt-4o-mini", // modelo por defecto en OpenRouter
  maxTokens: 1024,
  timeout: 30000,
};

export const SHEETS_SCOPES = ["https://www.googleapis.com/auth/spreadsheets"];

export const PROMPTS = {
  idea: `Eres un asistente experto en innovacion. Genera 3 ideas creativas basadas en este texto: '{TEXT}'. Cada idea debe tener: titulo, descripcion breve y potencial aplicacion. Responde en espanol.`,

  script: `Eres un guionista experto. Crea un script estructurado para un video de 3 minutos basado en este texto: '{TEXT}'. Incluye: introduccion, 3 puntos clave, conclusion y call to action. Responde en espanol.`,

  summary: `Resume este texto en 3 parrafos claros y concisos: '{TEXT}'. Responde en espanol.`,

  analyzeSources: `Eres un asistente de investigacion. Analiza la siguiente afirmacion y las fuentes encontradas. Para cada fuente, indica si RESPALDA, REFUTA o es NEUTRAL respecto a la afirmacion, y explica por que brevemente.

Afirmacion: "{TEXT}"

Fuentes:
{SOURCES}

Responde en espanol con el formato:
- [RESPALDA|REFUTA|NEUTRAL] Titulo de la fuente: explicacion breve`,
};

// Sitios de baja calidad para filtrar en búsquedas
export const LOW_QUALITY_DOMAINS = [
  "pinterest.",
  "quora.com",
  "yahoo.com",
  "wikihow",
  "answers.",
  "ehow.",
];

// Señales de contenido profundo para scoring
export function scoreResult(item) {
  let score = 0;
  const url = (item.link || "").toLowerCase();
  const snippet = item.snippet || "";
  const title = (item.title || "").toLowerCase();

  if (url.includes("medium.com") || url.includes("substack.com")) score += 3;
  if (url.includes("github.com") || url.includes("dev.to")) score += 3;
  if (url.includes("youtube.com")) score += 2;
  if (url.includes("reddit.com")) score += 2;
  if (url.includes(".edu") || url.includes("research")) score += 3;
  if (url.includes("blog.") || url.includes("/blog/")) score += 1;

  if (title.includes("guide") || title.includes("guia")) score += 2;
  if (title.includes("deep") || title.includes("complete")) score += 2;
  if (title.includes("tutorial") || title.includes("how to")) score += 1;
  if (title.includes("why") || title.includes("por qué")) score += 1;

  if (snippet.length > 150) score += 1;

  return score;
}
