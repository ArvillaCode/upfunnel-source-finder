# 📖 Guía para la Comunidad UpFunnel

## Cómo usar el Source Finder — Paso a paso

---

## 1. Instalar la extensión

1. Descargá la carpeta `upfunnel-source-finder`
2. Abrí Chrome y andá a `chrome://extensions/`
3. Activá **"Modo desarrollador"** (esquina superior derecha)
4. Clic en **"Cargar descomprimida"** y seleccioná la carpeta
5. Fijá el ícono en la barra (clic en el puzzle → pin 📌)

¡Listo! Ahora configurémosla.

---

## 2. Configurar las API keys (elegí una opción)

La extensión necesita **dos cosas**: un buscador y una IA. Acá están todas las opciones:

### 🔍 Opción A: Solo búsqueda (recomendado para empezar)

Con **Serper.dev** las búsquedas funcionan al toque:

1. Andá a [serper.dev](https://serper.dev) y registrate con Google
2. Te dan **$50 de crédito gratis** (como 25000 búsquedas)
3. Copiá la API key que aparece en el dashboard
4. En la extensión → pestaña **Config** → pegala en "Serper.dev API Key"
5. Hacé clic en **"Guardar configuración"**

> ✅ Con solo esto ya podés buscar fuentes. Sin IA por ahora.

---

### 🤖 Opción B: OpenRouter (la más recomendada)

OpenRouter te deja usar **cualquier modelo de IA con una sola key**, incluyendo modelos **totalmente gratis**:

1. Andá a [openrouter.ai/keys](https://openrouter.ai/keys)
2. Registrate (podés usar Google o GitHub)
3. Clic en **"Create API Key"** → copiala
4. En la extensión → **Config** → pegala en "OpenRouter API Key"
5. En "Modelo en OpenRouter" poné uno de estos:

   | Modelo | Costo | Calidad |
   |--------|-------|---------|
   | `mistralai/mistral-7b-instruct` | **Gratis** ✅ | Buena |
   | `meta-llama/llama-3-8b-instruct` | **Gratis** ✅ | Buena |
   | `cognitivecomputations/dolphin-mixtral-8x7b` | **Gratis** ✅ | Muy buena |
   | `openai/gpt-4o-mini` | ~$0.15/1000 consultas | Excelente |
   | `anthropic/claude-3-haiku` | ~$0.25/1000 consultas | Excelente |

6. Seleccioná "OpenRouter" como proveedor preferido
7. **Guardar configuración**

> 💡 **Tip**: Empezá con `mistralai/mistral-7b-instruct` que es gratis. Si necesitás más calidad, cambiá a uno de pago.

---

### 🆓 Opción C: Solo gratis (sin gastar un peso)

Si no querés poner tarjeta en ningún lado:

1. Buscador: La extensión usa **DuckDuckGo** gratis automáticamente
2. IA: Necesitás **Chrome 128+** para usar Gemini Nano (nativo, sin key)
3. En **Config** → seleccioná "Gemini Nano" como proveedor de IA
4. **Guardar configuración**

> ⚠️ Gemini Nano solo funciona en Chrome 128+. Si no lo tenés, actualizá Chrome.

---

### 💳 Opción D: OpenAI directo (si ya tenés cuenta)

1. Andá a [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Clic en **"Create new secret key"**
3. Copiala (empieza con `sk-...`)
4. En la extensión → **Config** → pegala en "OpenAI API Key"
5. Seleccioná "OpenAI" como proveedor preferido
6. **Guardar configuración**

> 🆓 **OpenAI te da $5 gratis** al registrarte por primera vez. No necesitás la suscripción de ChatGPT ($20/mes), eso es aparte.

---

## 3. Cómo usar la extensión

### Buscar fuentes

1. Navegá a cualquier página web
2. **Seleccioná un texto** con el mouse (como cuando copiás algo)
3. El texto se resalta automáticamente en amarillo
4. Abrí el panel lateral (clic en el ícono de la extensión)
5. En **Resaltados** → clic en **"🔍 Buscar fuentes"**
6. En segundos aparecen las fuentes encontradas

### Generar contenido con IA

Al lado de cada resaltado hay botones:

- **Generar Idea** → crea 3 ideas de contenido basadas en ese texto
- **Generar Script** → arma un guion para video de 3 minutos
- **Resumir** → hace un resumen en 3 párrafos

### Guardar en Google Sheets (opcional)

1. En **Config** → sección Google Sheets
2. Clic en **"Conectar Google Sheets"**
3. Chrome te pide permiso para acceder a tus Sheets → aceptás
4. Se conecta automáticamente al sheet más reciente
5. Cada vez que buscás fuentes, se guardan automáticamente como filas nuevas

Podés probar la conexión con **"Probar escritura"**.

---

## 4. Preguntas frecuentes

**¿La extensión es gratis?**
Sí, la extensión en sí es gratis. Lo único que pagás (si querés) son las APIs que vos configurás. Con modelos gratis de OpenRouter no gastás nada.

**¿Mis datos se envían a algún servidor?**
Todo va directo desde tu navegador a las APIs que configuraste. No hay servidores intermedios, no hay backend del creador.

**¿OpenRouter es seguro?**
Sí, OpenRouter es un proxy de APIs usado por miles de personas. No ven el contenido de tus consultas, solo las redirigen al modelo que elegiste.

**¿Puedo usar la extensión sin internet?**
No, necesita internet para buscar fuentes y generar contenido. Los resaltados se guardan localmente.

**¿Cómo cambio entre modelos de IA?**
En **Config** → cambiá el proveedor preferido o el modelo en OpenRouter. Guardá y listo.

**¿Pierdo los resaltados si cierro Chrome?**
No, se guardan en el almacenamiento local de Chrome. Solo se pierden si desinstalás la extensión.

---

## 5. Resumen rápido de costos

| Configuración | Costo mensual | Para quién |
|---------------|--------------|------------|
| DuckDuckGo + Gemini Nano | **$0** | El que no quiere poner tarjeta |
| Serper + OpenRouter (modelo gratis) | **$0** (~25000 búsquedas gratis en Serper) | El que investiga mucho |
| Serper + OpenRouter (GPT-4o-mini) | ~$5-10 | Uso profesional |
| Serper + OpenAI directo | ~$5-15 | El que ya tiene cuenta OpenAI |

---

¿Problemas o dudas? Preguntá en la comunidad UpFunnel 🙌
