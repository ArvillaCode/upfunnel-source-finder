# Configurar Google Sheets OAuth

## Paso 1: Crear Client ID en Google Cloud

1. Andá a https://console.cloud.google.com/
2. Creá un proyecto nuevo (o usá uno existente)
3. **APIs y servicios → Biblioteca** → buscá **Google Sheets API** → **Habilitar**
4. **APIs y servicios → Pantalla de consentimiento de OAuth**
   - Tipo: **Externo**
   - Nombre de la app: `UpFunnel Source Finder`
   - Correo de asistencia: tu correo
   - Correo del desarrollador: tu correo
   - **Agregar scopes** → pegá `https://www.googleapis.com/auth/spreadsheets` → **Guardar**
   - **Usuarios de prueba** → **AGREGÁ TU CORREO** (esto es clave para evitar el error "no verificado")
   - **Guardar**
5. **APIs y servicios → Credenciales → Crear credenciales → ID de cliente de OAuth**
   - Tipo: **Extensión de Chrome**
   - ID de la extensión: **`pcggghoalfjaknhnlcckkffignbjaiol`**
   - **Crear**
6. Copiá el **Client ID** (termina en `.apps.googleusercontent.com`)

## Paso 2: Pegar el Client ID en la extensión

1. Abrí `manifest.json`
2. Reemplazá `REEMPLAZAR_CON_TU_CLIENT_ID` con el Client ID real
3. Recargá la extensión en `chrome://extensions/`

## Paso 3: Probar

1. En la extensión → **Config**
2. Pegá la URL de tu Google Sheet: `https://docs.google.com/spreadsheets/d/TU_ID/`
3. Clic en **🔗 Conectar Google**
4. Aparece el popup de Google → **Permitir**
5. ✅ Listo

## Para que otros miembros de la comunidad usen OAuth

Cada miembro necesita ser agregado como **usuario de prueba** en la pantalla de consentimiento. Agregá los correos de los miembros desde:
**APIs y servicios → Pantalla de consentimiento de OAuth → Usuarios de prueba → AGREGAR USUARIOS**

## Columnas

| Columna | Contenido |
|---------|-----------|
| id | ID interno del resaltado |
| texto | Texto seleccionado |
| url_pagina | URL de la página |
| titulo_pagina | Título de la página |
| titulo_fuente | Título de la fuente encontrada |
| url_fuente | URL de la fuente |
| relevancia | Por qué es relevante |
| fecha | Fecha y hora |
