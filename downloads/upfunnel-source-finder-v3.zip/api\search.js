// api/search.js — Módulo de búsqueda con auto-failover

import {
  API_ENDPOINTS,
  SEARCH_DEFAULTS,
  LOW_QUALITY_DOMAINS,
  scoreResult,
} from "./config.js";

// ── Providers ────────────────────────────────────────────────────────

async function serperSearch(query, apiKeys, signal) {
  const res = await fetch(API_ENDPOINTS.serper, {
    method: "POST",
    headers: {
      "X-API-KEY": apiKeys.serper,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ q: query, num: SEARCH_DEFAULTS.numResults }),
    signal,
  });

  if (!res.ok) throw new Error(`Serper HTTP ${res.status}`);
  const data = await res.json();
  return formatOrganicResults(data.organic || []);
}

async function googleCseSearch(query, apiKeys, signal) {
  const { apiKey, cx } = apiKeys.googleCse;
  if (!apiKey || !cx) throw new Error("Google CSE no configurado");

  const url = new URL(API_ENDPOINTS.googleCse);
  url.searchParams.set("key", apiKey);
  url.searchParams.set("cx", cx);
  url.searchParams.set("q", query);
  url.searchParams.set("num", String(SEARCH_DEFAULTS.numResults));
  url.searchParams.set("lr", "lang_es");

  const res = await fetch(url.toString(), { signal });
  if (!res.ok) throw new Error(`Google CSE HTTP ${res.status}`);
  const data = await res.json();
  const items = data.items || [];
  return items.map((item) => ({
    title: item.title || "",
    link: item.link || "",
    snippet: item.snippet || "",
  }));
}

async function duckduckgoSearch(query, _apiKeys, signal) {
  const url = new URL(API_ENDPOINTS.duckduckgo);
  url.searchParams.set("q", query);
  url.searchParams.set("format", "json");
  url.searchParams.set("no_html", "1");
  url.searchParams.set("skip_disambig", "1");

  const res = await fetch(url.toString(), { signal });
  if (!res.ok) throw new Error(`DuckDuckGo HTTP ${res.status}`);
  const data = await res.json();

  const results = [];

  // Abstract + Answer
  if (data.AbstractText) {
    results.push({
      title: data.Heading || "DuckDuckGo Answer",
      link: data.AbstractURL || "",
      snippet: data.AbstractText,
    });
  }

  // Related topics
  if (data.RelatedTopics) {
    for (const topic of data.RelatedTopics) {
      if (topic.Text) {
        results.push({
          title: topic.Text,
          link: topic.FirstURL || "",
          snippet: topic.Text,
        });
      }
      // Nested topics (subcategories)
      if (topic.Topics) {
        for (const sub of topic.Topics) {
          if (sub.Text) {
            results.push({
              title: sub.Text,
              link: sub.FirstURL || "",
              snippet: sub.Text,
            });
          }
        }
      }
    }
  }

  return results;
}

// ── Orden de providers según lo configurado ─────────────────────────

function getSearchOrder(apiKeys) {
  const order = [];
  if (apiKeys.serper) order.push("serper");
  if (apiKeys.googleCse?.apiKey && apiKeys.googleCse?.cx) order.push("googleCse");
  order.push("duckduckgo"); // siempre disponible como fallback final
  return order;
}

// ── Formateo común ──────────────────────────────────────────────────

function formatOrganicResults(items) {
  return items.map((item) => ({
    title: item.title || "",
    link: item.link || "",
    snippet: item.snippet || "",
  }));
}

function filterLowQuality(results) {
  return results.filter(
    (item) =>
      !LOW_QUALITY_DOMAINS.some((d) => (item.link || "").toLowerCase().includes(d))
  );
}

function scoreAndSort(results) {
  return results
    .map((item) => ({ ...item, score: scoreResult(item) }))
    .sort((a, b) => b.score - a.score);
}

function formatSources(results) {
  return scoreAndSort(results)
    .slice(0, SEARCH_DEFAULTS.maxResults)
    .map((item) => ({
      title: item.title,
      url: item.link,
      why_relevant: item.snippet ? item.snippet.slice(0, 220) : "",
    }));
}

// ── Módulo público ──────────────────────────────────────────────────

const providers = { serper: serperSearch, googleCse: googleCseSearch, duckduckgo: duckduckgoSearch };

/**
 * Busca fuentes con auto-failover entre providers.
 * @param {string} query - Texto a buscar
 * @param {object} apiKeys - { serper, googleCse: { apiKey, cx } }
 * @returns {Promise<{success: boolean, sources: Array, provider?: string, error?: string}>}
 */
export async function searchWithFallback(query, apiKeys, excludeUrl = "") {
  const order = getSearchOrder(apiKeys);

  for (const provider of order) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), SEARCH_DEFAULTS.timeout);

    try {
      const results = await providers[provider](query, apiKeys, controller.signal);
      clearTimeout(timeout);

      const filtered = filterLowQuality(results);
      let sources = formatSources(filtered);

      // Excluir la página actual
      if (excludeUrl) {
        const normalized = excludeUrl.replace(/\/$/, "").toLowerCase();
        sources = sources.filter(s => !s.url || s.url.replace(/\/$/, "").toLowerCase() !== normalized);
      }

      if (sources.length > 0) {
        return { success: true, sources, provider };
      }
    } catch (err) {
      clearTimeout(timeout);
      console.warn(`[Search] ${provider} falló:`, err.message);
      // continuar al siguiente provider
    }
  }

  return { success: false, sources: [], error: "Todos los proveedores de búsqueda fallaron" };
}

export async function searchWithProvider(query, provider, apiKeys, excludeUrl = "") {
  if (!providers[provider]) throw new Error(`Provider desconocido: ${provider}`);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), SEARCH_DEFAULTS.timeout);

  try {
    const results = await providers[provider](query, apiKeys, controller.signal);
    clearTimeout(timeout);
    const filtered = filterLowQuality(results);
    let sources = formatSources(filtered);
    if (excludeUrl) {
      const normalized = excludeUrl.replace(/\/$/, "").toLowerCase();
      sources = sources.filter(s => !s.url || s.url.replace(/\/$/, "").toLowerCase() !== normalized);
    }
    return { success: true, sources, provider };
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}
