// service-worker.js — Manifest V3 Event-Based Background

import { searchWithFallback } from "./api/search.js";
import { generateWithAI, isGeminiNanoAvailable } from "./api/ai.js";

// ── Instalación / Startup ───────────────────────────────────────────

chrome.runtime.onInstalled.addListener((details) => {
  console.log("[UpFunnel] Extension instalada y lista.");
  chrome.storage.local.set({
    highlights: [],
    captures: [],
    captureEnabled: true,
    sources: {},
    apiKeys: {},
    preferredSearch: "serper",
    preferredAI: "openai",
    sheetsConfig: {},
  });
  if (details.reason === "install" || details.reason === "update") {
    reinjectContentScripts();
  }
});

chrome.runtime.onStartup.addListener(() => {
  reinjectContentScripts();
});

function reinjectContentScripts() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.url && tab.url.startsWith("http")) {
        chrome.scripting
          .executeScript({ target: { tabId: tab.id }, files: ["content-script.js"] })
          .catch(() => {});
      }
    });
  });
}

// ── Action + Commands ───────────────────────────────────────────────

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-capture") {
    chrome.storage.local.get(["captureEnabled"], (result) => {
      chrome.storage.local.set({ captureEnabled: result.captureEnabled === false });
    });
  }
  if (command === "toggle-theme") {
    chrome.storage.local.get(["theme"], (result) => {
      const current = result.theme || "light";
      chrome.storage.local.set({ theme: current === "light" ? "dark" : "light" });
    });
  }
});

// ── Message Router ──────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    switch (message.action) {
      // ── Highlights ──
      case "saveHighlight":
        handleSaveHighlight(message.highlight, sendResponse);
        return true;
      case "getHighlights":
        chrome.storage.local.get(["highlights"], (r) =>
          sendResponse({ highlights: r.highlights || [] })
        );
        return true;
      case "deleteHighlight":
        handleDeleteHighlight(message.id, sendResponse);
        return true;
      case "clearAll":
        chrome.storage.local.set({ highlights: [], captures: [], sources: {} }, () =>
          sendResponse({ success: true })
        );
        return true;

      // ── Capturas ──
      case "captureTab":
        handleCaptureTab(sender, sendResponse);
        return true;
      case "saveCapture":
        handleSaveCapture(message, sendResponse);
        return true;
      case "deleteCaptureById":
        handleDeleteCapture(message.id, sendResponse);
        return true;

      // ── Búsqueda de fuentes ──
      case "findSources":
        handleFindSources(message.highlightId, message.text, sendResponse);
        return true;
      case "getSources":
        chrome.storage.local.get(["sources"], (r) =>
          sendResponse({ sources: r.sources || {} })
        );
        return true;
      case "deleteSource":
        handleDeleteSource(message.highlightId, message.sourceIndex, sendResponse);
        return true;

      // ── IA ──
      case "generateAI":
        handleGenerateAI(message, sendResponse);
        return true;
      case "checkGeminiNano":
        isGeminiNanoAvailable().then((available) =>
          sendResponse({ available })
        );
        return true;

      // ── API Keys ──
      case "saveApiKeys":
        chrome.storage.local.set({ apiKeys: message.apiKeys }, () =>
          sendResponse({ success: true })
        );
        return true;
      case "getApiKeys":
        chrome.storage.local.get(["apiKeys"], (r) =>
          sendResponse({ apiKeys: r.apiKeys || {} })
        );
        return true;
      case "savePreferences":
        chrome.storage.local.set(
          { preferredSearch: message.preferredSearch, preferredAI: message.preferredAI },
          () => sendResponse({ success: true })
        );
        return true;
      case "getPreferences":
        chrome.storage.local.get(["preferredSearch", "preferredAI"], (r) =>
          sendResponse(r)
        );
        return true;

      // ── Sheets Webhook ──
      case "sheetsTestWebhook":
        handleSheetsTestWebhook(message.url, sendResponse);
        return true;
      case "sheetsSaveUrl":
        chrome.storage.local.set({ sheetsWebhookUrl: message.url, sheetsConnected: true }, () =>
          sendResponse({ success: true })
        );
        return true;
      case "sheetsDisconnect":
        chrome.storage.local.set({ sheetsWebhookUrl: "", sheetsConnected: false }, () =>
          sendResponse({ success: true })
        );
        return true;
      case "sheetsGetStatus":
        chrome.storage.local.get(["sheetsWebhookUrl", "sheetsConnected"], (r) =>
          sendResponse(r)
        );
        return true;
      case "sheetsAppendRow":
        handleSheetsAppendRow(message.values, sendResponse);
        return true;

      case "translateText":
        handleTranslateText(message.text, sendResponse);
        return true;

      case "exportToAI":
        handleExportToAI(message, sendResponse);
        return true;

      default:
        sendResponse({ success: false, error: `Acción desconocida: ${message.action}` });
    }
  } catch (err) {
    console.warn("[UpFunnel] onMessage error:", err);
    sendResponse({ success: false, error: err.message });
  }
});

// ── Captura de pantalla ─────────────────────────────────────────────

async function handleCaptureTab(sender, sendResponse) {
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!activeTab) {
      sendResponse({ success: false, error: "No se encontró pestaña activa." });
      return;
    }
    const dataUrl = await chrome.tabs.captureVisibleTab(activeTab.windowId, {
      format: "png",
      quality: 95,
    });
    sendResponse({
      success: true,
      dataUrl,
      meta: { url: activeTab.url, title: activeTab.title },
    });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

function handleSaveCapture(message, sendResponse) {
  const capture = {
    id: Date.now(),
    url: message.meta?.url || "",
    title: message.meta?.title || "Sin título",
    dataUrl: message.dataUrl,
    timestamp: new Date().toISOString(),
  };
  chrome.storage.local.get(["captures"], (result) => {
    const captures = result.captures || [];
    captures.push(capture);
    chrome.storage.local.set({ captures }, () => sendResponse({ success: true, capture }));
  });
}

async function handleDeleteCapture(id, sendResponse) {
  try {
    const result = await chrome.storage.local.get(["captures"]);
    const captures = (result.captures || []).filter((c) => c.id !== id);
    await chrome.storage.local.set({ captures });
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ── Highlights ──────────────────────────────────────────────────────

function handleSaveHighlight(highlight, sendResponse) {
  chrome.storage.local.get(["highlights"], (result) => {
    const highlights = result.highlights || [];
    const isDuplicate = highlights.some((h) => h.text === highlight.text);
    if (isDuplicate) {
      sendResponse({ success: false, reason: "duplicate" });
      return;
    }
    highlights.push(highlight);
    chrome.storage.local.set({ highlights }, () => sendResponse({ success: true }));
  });
}

async function handleDeleteHighlight(id, sendResponse) {
  try {
    const result = await chrome.storage.local.get(["highlights"]);
    const highlights = (result.highlights || []).filter((h) => h.id !== id);
    await chrome.storage.local.set({ highlights });
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ── Búsqueda de fuentes ─────────────────────────────────────────────

async function handleFindSources(highlightId, text, sendResponse) {
  try {
    const { apiKeys, preferredSearch, highlights } = await chrome.storage.local.get([
      "apiKeys",
      "preferredSearch",
      "highlights",
    ]);

    // Obtener datos del highlight para excluir la página actual
    const hl = (highlights || []).find(h => h.id === highlightId);
    const pageUrl = hl?.url || "";
    const pageTitle = hl?.pageTitle || "";

    // Obtener URLs ya encontradas para este highlight
    const { sources: allSources } = await chrome.storage.local.get(["sources"]);
    const existingSources = (allSources && allSources[highlightId]) || [];
    const existingUrls = new Set(existingSources.map(s => s.url).filter(Boolean));

    // Mejorar query: agregar contexto de la página
    const query = pageTitle ? `${text} - ${pageTitle}` : text;

    const result = await searchWithFallback(query, apiKeys, pageUrl);
    
    // Filtrar URLs ya vistas
    if (result.success && result.sources.length > 0) {
      result.sources = result.sources.filter(s => !existingUrls.has(s.url));
    }

    sendResponse(result);

    if (result.success && result.sources.length > 0) {
      const updated = allSources || {};
      updated[highlightId] = [...existingSources, ...result.sources];
      await chrome.storage.local.set({ sources: updated });
    }
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

async function handleDeleteSource(highlightId, sourceIndex, sendResponse) {
  try {
    const { sources: allSources } = await chrome.storage.local.get(["sources"]);
    const sources = allSources || {};
    const sourceList = sources[highlightId] || [];
    sourceList.splice(sourceIndex, 1);
    if (sourceList.length === 0) delete sources[highlightId];
    else sources[highlightId] = sourceList;
    await chrome.storage.local.set({ sources });
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ── IA ──────────────────────────────────────────────────────────────

async function handleGenerateAI(message, sendResponse) {
  try {
    const { apiKeys, preferredAI } = await chrome.storage.local.get([
      "apiKeys",
      "preferredAI",
    ]);

    // Auto-detectar provider disponible si el preferido no tiene key
    const aiPriority = [
      preferredAI || "openai",
      "openrouter",
      "openai",
      "claude",
      "gemini-nano",
    ];

    let provider = aiPriority[0];
    for (const p of aiPriority) {
      if (p === "gemini-nano") {
        // Gemini Nano no necesita key, lo intentamos siempre
        provider = p;
        break;
      }
      if (apiKeys[p]) {
        provider = p;
        break;
      }
    }

    const result = await generateWithAI(
      message.type,
      message.text,
      apiKeys,
      provider,
      { sources: message.sources }
    );

    sendResponse(result);
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ── Export ─────────────────────────────────────────────────────────

async function handleExportToAI(message, sendResponse) {
  chrome.storage.local.get(["highlights", "captures"], async (result) => {
    const payload = {
      exported_at: new Date().toISOString(),
      session_id: `session_${Date.now()}`,
      highlights: result.highlights || [],
      captures_count: (result.captures || []).length,
      captures_metadata: (result.captures || []).map((c) => ({
        id: c.id,
        url: c.url,
        title: c.title,
        timestamp: c.timestamp,
      })),
      prompt_context: buildPromptContext(result.highlights || []),
    };
    sendResponse({ success: true, payload });
  });
}

function buildPromptContext(highlights) {
  if (!highlights.length) return "No hay resaltados disponibles.";
  return highlights
    .map(
      (h, i) =>
        `[${i + 1}] "${h.text}" — Fuente: ${h.pageTitle || "Sin título"} (${h.url || "URL no disponible"})`
    )
    .join("\n");
}

// ── Traducción ────────────────────────────────────────────────────

async function handleTranslateText(text, sendResponse) {
  try {
    const { apiKeys } = await chrome.storage.local.get(["apiKeys"]);
    const key = apiKeys?.openai || apiKeys?.openrouter || apiKeys?.claude;
    if (!key) { sendResponse({ success: false }); return; }

    const provider = apiKeys.openai ? "openai" : apiKeys.openrouter ? "openrouter" : "claude";
    const endpoint = provider === "openai" ? "https://api.openai.com/v1/chat/completions"
      : provider === "openrouter" ? "https://openrouter.ai/api/v1/chat/completions"
      : "https://api.anthropic.com/v1/messages";

    const body = provider === "claude" ? JSON.stringify({
      model: "claude-3-haiku-20240307",
      max_tokens: 300,
      messages: [{ role: "user", content: `Traduce esto al español (SOLO el texto traducido, sin explicaciones):\n\n${text}` }]
    }) : JSON.stringify({
      model: provider === "openrouter" ? "openai/gpt-4o-mini" : "gpt-4o-mini",
      messages: [{ role: "user", content: `Traduce esto al español. Responde SOLO con el texto traducido:\n\n${text}` }],
    });

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(provider === "claude" ? { "x-api-key": key, "anthropic-version": "2023-06-01" } : { Authorization: `Bearer ${key}` }),
      },
      body,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const translated = provider === "claude" ? data.content?.[0]?.text : data.choices?.[0]?.message?.content;
    sendResponse({ success: true, translated: translated?.trim() || text });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ── Sheets Webhook ─────────────────────────────────────────────────

async function handleSheetsTestWebhook(url, sendResponse) {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ test: true, timestamp: new Date().toISOString(), source: "UpFunnel Source Finder" }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

async function handleSheetsAppendRow(values, sendResponse) {
  try {
    const { sheetsWebhookUrl } = await chrome.storage.local.get(["sheetsWebhookUrl"]);
    if (!sheetsWebhookUrl) {
      sendResponse({ success: false, error: "URL de webhook no configurada" });
      return;
    }
    const rowData = {
      id: values[0] || "",
      texto: values[1] || "",
      url_pagina: values[2] || "",
      titulo_pagina: values[3] || "",
      titulo_fuente: values[4] || "",
      url_fuente: values[5] || "",
      relevancia: values[6] || "",
      fecha: values[7] || "",
    };
    const res = await fetch(sheetsWebhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(rowData),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}


